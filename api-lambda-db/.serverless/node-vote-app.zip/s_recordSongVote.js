
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'amitmahajancloud',
  applicationName: 'node-vote-app',
  appUid: 'y0xX7pctfrZBv5sDB0',
  orgUid: 'CH627CshDmgClVBThF',
  deploymentUid: 'c81d7cf1-c48a-4eac-8ac7-5ce72a21d228',
  serviceName: 'node-vote-app',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.6',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'node-vote-app-dev-recordSongVote', timeout: 6 };

try {
  const userHandler = require('./addVote.js');
  module.exports.handler = serverlessSDK.handler(userHandler.update, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}